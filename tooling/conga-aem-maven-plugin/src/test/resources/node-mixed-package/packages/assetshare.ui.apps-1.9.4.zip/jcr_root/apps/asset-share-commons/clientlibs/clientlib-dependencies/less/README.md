The import of grid_base.less via this "copy-down" location is required by Asset Share Commons to support both AEM 6.3.1 and 6.4.

This file is a copy-down from AEM 6.4.0 @ /libs/wcm/foundation/clientlibs/grid/grid_base.less

Normally, the AEM-provided grid_base.less file would be directly referenced.
on the target version of AEM.

  - AEM 6.3.1: /etc/clientlibs/wcm/foundation/grid/grid_base.less
  - AEM 6.4:   /libs/wcm/foundation/clientlibs/grid/grid_base.less


This file is referenced by:

  - /apps/asset-share-commons/clientlibs/clientlib-site/less/grid.less